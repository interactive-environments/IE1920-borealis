class Segment {
  public:
    Segment(Adafruit_NeoPixel&, int, int);
    Adafruit_NeoPixel ledStrip;
    int startPixel;
    int endPixel;

    int animationType;
    int animationDirection;
    int animationUpdateInterval;
    int animationDuration;

    int count = 0;
    int i = 0;

    int activeLed;
    long lastAnimationUpdate;

    // this serve to time the animations after a certain time
    long animationInitialized;
    int delayTime;
    boolean animationisOver = true;
    boolean animationStarted = false;

    void initAnimation(int, int, int, int);
    void updateAnimation();
    boolean isAnimationOver();

    void setColor(int, int, int);
    void turnOffSegment();
    int color[3];
};

Segment::Segment(Adafruit_NeoPixel &ledStrip, int startPixel, int endPixel) {
  this->ledStrip = ledStrip;
  this->startPixel = startPixel;
  this->endPixel = endPixel;
}

void Segment::setColor(int red, int green, int blue) {
  this->color[0] = red;
  this->color[1] = green;
  this->color[2] = blue;
}

void Segment::initAnimation(int animationType, int animationDuration, int animationDirection, int delaytime) {
  this->animationDuration = animationDuration;
  this->animationType = animationType;
  this->animationDirection = animationDirection;
  this->animationisOver = false;

  int nLeds = endPixel - startPixel;
  Serial.println(String("n leds") + nLeds);
  this->animationUpdateInterval = animationDuration / nLeds;
  Serial.println(String("update int") + animationUpdateInterval);


  this->delayTime = delaytime;
  this->animationInitialized = millis();
  //Serial.println("Init animation");
  //Serial.println(animationInitialized);

  if (animationDirection == 1) {
    this->activeLed = this->startPixel;
  } else if (animationDirection == -1) {
    this->activeLed = this->endPixel;
  }
}

boolean Segment::isAnimationOver() {
  return animationisOver;
}

void Segment::updateAnimation() {

  if (millis() - animationInitialized > delayTime) {
    //    Serial.println(millis() - animationInitialized);
    animationStarted = true;
  }

  if (animationStarted && millis() - lastAnimationUpdate > animationUpdateInterval && animationUpdateInterval != 0) {
//    Serial.println(String("time: ") + millis());
//    Serial.println(lastAnimationUpdate);
//    Serial.println(animationUpdateInterval);
    switch (this->animationType) {
      case 0:
        this->activeLed += animationDirection;
        if (activeLed < this->startPixel || activeLed > this->endPixel) {
          animationisOver = true;
        } else {
          ledStrip.setPixelColor(this->activeLed, ledStrip.Color(this->color[0], this->color[1], this->color[2]));
          ledStrip.show();
        }
        break;
      case 1:
        this->activeLed += animationDirection;
        if (activeLed < this->startPixel || activeLed > this->endPixel) {
          animationisOver = true;
        } else {
          ledStrip.setPixelColor(this->activeLed, ledStrip.Color(0,0,0));
          ledStrip.show();
        }
        break;
      case 2:
        this->activeLed += animationDirection;
        if (activeLed < this->startPixel || activeLed + 1 > this->endPixel) {
          activeLed = startPixel;
        } else {
          ledStrip.setPixelColor(this->activeLed, ledStrip.Color(0, 0, 0));
          ledStrip.setPixelColor(this->activeLed + 1, ledStrip.Color(this->color[0], this->color[1], this->color[2]));
          ledStrip.show();
        }
        break;
      case 3: //Meeting In Middle animation Colorred
            count++;
            i = -0.02 * ((count - 50)*(count - 50)) + 50; //Parabola expression to control the color the variable i up to 100 and down to 0 again over 1 second - if 50 is wanted instead of 100, halve -0.0004 to -0.0002
            for(int j = startPixel; j < endPixel; j++) {
              ledStrip.setPixelColor(j, ledStrip.Color(this->color[0], this->color[1] + i, this->color[2] + i)); // Animationdirection must be == 1
              ledStrip.show();
            }
            if (count == 100) {
              animationisOver = true;
              i = 0;
          }
        break;
    }
    lastAnimationUpdate = millis();
  }
}
